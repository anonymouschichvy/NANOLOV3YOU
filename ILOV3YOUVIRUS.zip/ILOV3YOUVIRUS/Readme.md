# CHROME VIRUS

For Educational Purposes Only.
Warning , this virus is never been tested.
Pls disabled the windows anti-virus sofware.
If the virus don't work,its because there's a bug in the codes.
I ALREADY TRY MY BEST TO BUILD IT :)
Chrome Icon and name is only for incognito so they don't know it's a virus.
IM NOT AN EXPERT TO MAKE IT.
TOO MANY BUGS IN THE SYSTEM CODES.

# ⚠️Warning If you run the EXE Make sure you run it on VIRTUAL MACHINE and turn of the internet#